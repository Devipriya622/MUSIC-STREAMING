import logo from "./logo.svg";
import "./App.css";
import { LeftMenu } from "./Components/LeftMenu";
import { MainContainer } from "./Components/MainContainer";
import { RightMenu } from "./Components/RightMenu";
import {AudioList} from "./Components/AudioList";
import AddSong from "./Components/AddSong";
// import axios from 'axios'
function App() {
 
  //  axios.get('http://localhost:3000/0')
  //  axios.get('http://localhost:3000/1')
  
  //   axios.get('http://localhost:3000/2')
  //   axios.get('http://localhost:3000/3')
  //     axios.get('http://localhost:3000/4')
  //       axios.get('http://localhost:3000/5')
  //         axios.get('http://localhost:3000/6')
  //           axios.get('http://localhost:3000/7')
  return (
    <div className="App">
      <div className=""></div>
      <LeftMenu />
      <MainContainer />
      <RightMenu />
      <AddSong/>
       {/* <AudioList /> */}

      <div className="background"></div>
    </div>
  );
}

export default App;
