// import React, { useState, useEffect } from "react";
// import { FaHeadphones, FaRegClock, FaRegHeart, FaHeart } from "react-icons/fa";
// import "../styles/LeftMenu.css";
// import MusicPlayer from "./MusicPlayer";
// import { Songs } from "./Songs";

// function AudioList() {
//   const [songs, setSongs] = useState([])
//   axios.get('http://localhost:3000/songs')
//   .then((res)=> {
//     console.log(res.data)
//   })
//   .catch(()=> {
//     console.log('Error in Getting data')
//   })
//   }
//    /*(Songs);*/ // Default song list from Songs.js

//   // Add a new song (Create)




  // const addSong = (newSong) => {
  //   setSongs((prevSongs) => [...prevSongs, newSong]);
  //   setSong(newSong.song);
  //   setImage(newSong.imgSrc);
  //   setAuto(true);
  // };

//   // Update favorite status (Update)
//   const changeFavourite = (id) => {
//     const updatedSongs = songs.map((song) =>
//       song.id === id ? { ...song, favourite: !song.favourite } : song
//     );
//     setSongs(updatedSongs);
//   };

//   // Set a main song to play (Read)
//   const setMainSong = (songSrc, imgSrc) => {
//     setSong(songSrc);
//     setImage(imgSrc);
//     setAuto(true);
//   };

//   // Delete a song (Delete)
//   const deleteSong = (id) => {
//     setSongs((prevSongs) => prevSongs.filter((song) => song.id !== id));
//   };

//   // Handle the addition of a new song via a form
  // const handleAddSong = (e) => {
  //   e.preventDefault();

  //   const newSong = {
  //     id: Date.now(), // Unique ID based on timestamp
  //     songName: e.target.songName.value,
  //     artist: e.target.artist.value,
  //     imgSrc: e.target.imgSrc.value,
  //     song: e.target.songSrc.value,
  //     favourite: false,
  //   };

  //   addSong(newSong);
  //   e.target.reset(); // Reset the form after submission
  // };

//   // Effect to update the active song when clicked
//   useEffect(() => {
//     const allSongs = document.querySelectorAll(".songs");
//     function changeActive() {
//       allSongs.forEach((n) => n.classList.remove("active"));
//       this.classList.add("active");
//     }

//     allSongs.forEach((n) => n.addEventListener("click", changeActive));
//   }, [songs]);

//   return (
//     <div>AudioList{songs.map((item)=>( 
//       <div>
//         <ul>
//           <li>{item.id}</li>
//           <li>{item.songName}</li>
//           <li>{item.artist}</li>
          
//         </ul>
//       </div>
//     ))}</div>
//   )
//     <div className="AudioList">
//       <h2 className="title">
//         The list <span>{`${songs.length} songs`}</span>
//       </h2>

//       <div className="songsContainer">
//         {songs.map((song, index) => (
//           <div
//             className="songs"
//             key={song.id}
//             onClick={() => setMainSong(song.song, song.imgSrc)}
//           >
//             <div className="count">
//               <p>{`#${index + 1}`}</p>
//             </div>
//             <div className="song">
//               <div className="imgBox">
//                 <img src={song.imgSrc} alt={song.songName} />
//               </div>
//               <div className="section">
//                 <p className="songName">
//                   {song.songName}
//                   <span className="songSpan">{song.artist}</span>
//                 </p>

//                 <div className="hits">
//                   <p className="hit">
//                     <i>
//                       <FaHeadphones />
//                     </i>
//                     95,490,102
//                   </p>

//                   <p className="duration">
//                     <i>
//                       <FaRegClock />
//                     </i>
//                     03:04
//                   </p>

//                   <div
//                     className="favourite"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       changeFavourite(song.id);
//                     }}
//                   >
//                     {song.favourite ? (
//                       <i>
//                         <FaHeart />
//                       </i>
//                     ) : (
//                       <i>
//                         <FaRegHeart />
//                       </i>
//                     )}
//                   </div>

//                   <button
//                     className="deleteButton"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       deleteSong(song.id);
//                     }}
//                   >
//                     Delete
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>

//       {/* Music Player */}
//       <MusicPlayer song={song} imgSrc={img} autoplay={auto} />

//       {/* Add New Song Form */}
      // <form onSubmit={handleAddSong} className="addSongForm">
      //   <h3>Add a New Song</h3>
      //   <input
      //     type="text"
      //     name="songName"
      //     placeholder="Song Name"
      //     required
      //   />
      //   <input
      //     type="text"
      //     name="artist"
      //     placeholder="Artist"
      //     required
      //   />
      //   <input
      //     type="text"
      //     name="imgSrc"
      //     placeholder="Image URL"
      //     required
      //   />
      //   <input
      //     type="text"
      //     name="songSrc"
      //     placeholder="Song URL"
      //     required
      //   />
      //   <button  
      //   type="submit">Add Song</button>
      // </form>
//     </div>
//   );
// }

// export { AudioList };
/*--------------------*/
// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { FaHeadphones, FaRegClock, FaRegHeart, FaHeart } from "react-icons/fa";

// function AudioList() {
//   const [songs, setSongs] = useState([]); // State to hold songs data
//   const [song, setSong] = useState(""); // Currently playing song URL
//   const [img, setImage] = useState(""); // Image for the current song
//   const [auto, setAuto] = useState(false); // Autoplay status

//   // Fetch songs data from the server
//   useEffect(() => {
//     axios
//       .get("http://localhost:3000/songs/")
//       .then((res) => {
//         setSongs(res.data);
//         console.log(res.data)
//       })
//       .catch(() => {
//         console.log("Error in Getting data");
//       });
//   }, []); // Run once when the component mounts

//   // Add a new song to the list
//   const addSong = (newSong) => {
//     setSongs((prevSongs) => [...prevSongs, newSong]);
//     setSong(newSong.song);
//     setImage(newSong.imgSrc);
//     setAuto(true);
//   };

//   // Toggle favorite status
//   const changeFavourite = (id) => {
//     const updatedSongs = songs.map((song) =>
//       song.id === id ? { ...song, favourite: !song.favourite } : song
//     );
//     setSongs(updatedSongs);
//   };

//   // Set a main song to play
//   const setMainSong = (songSrc, imgSrc) => {
//     setSong(songSrc);
//     setImage(imgSrc);
//     setAuto(true);
//   };

//   // Delete a song from the list
//   const deleteSong = (id) => {
//     // setSongs((prevSongs) => prevSongs.filter((song) => song.id !== id));
//     axios.delete(`http://localhost:3000/songs/${id}`)
//     .then(()=>{
//       console.log("deleted")
//       setSongs((prevSongs) => prevSongs.filter((song) => song.id !== id));
//     })
//     .catch(()=>{
//       console.log("Error")
//     })
//   };



//   return (
//     <div className="AudioList">
//       <h2 className="title">
//         The list <span>{`${songs.length} songs`}</span>
//       </h2>

//       <div className="songsContainer">
//         {songs.map((song, index) => (
//           <div
//             className="songs"
//             key={song.id}
//             onClick={() => setMainSong(song.song, song.imgSrc)}
//           >
//             <div className="count">
//               <p>{`#${index + 1}`}</p>
//             </div>
//             <div className="song">
//               <div className="imgBox">
//                 <img src={song.imgSrc} alt={song.songName} />
//               </div>
//               <div className="section">
//                 <p className="songName">
//                   {song.songName}
//                   <span className="songSpan">{song.artist}</span>
//                 </p>

//                 <div className="hits">
//                   <p className="hit">
//                     <i>
//                       <FaHeadphones />
//                     </i>
//                     95,490,102
//                   </p>

//                   <p className="duration">
//                     <i>
//                       <FaRegClock />
//                     </i>
//                     03:04
//                   </p>
// <audio controls src={song.song}></audio>
                

//                   <div
//                     className="favourite"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       changeFavourite(song.id);
//                     }}
//                   >
//                     {song.favourite ? (
//                       <i>
//                         <FaHeart />
//                       </i>
//                     ) : (
//                       <i>
//                         <FaRegHeart />
//                       </i>
//                     )}
//                   </div>

//                   <button
//                     className="deleteButton"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       deleteSong(song.id);
//                     }}
//                   >
//                     Delete


//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export { AudioList };
/*---------------------*/
import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaHeadphones, FaRegClock, FaRegHeart, FaHeart, FaTrashAlt } from "react-icons/fa";

function AudioList() {
  const [songs, setSongs] = useState([]);
  const [currentSong, setCurrentSong] = useState("");
  const [currentImage, setCurrentImage] = useState("");
  const [autoPlay, setAutoPlay] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:3000/songs/")
      .then((res) => {
        setSongs(res.data);
        console.log(res.data);
      })
      .catch(() => {
        console.log("Error in Getting data");
      });
  }, []);

  const toggleFavourite = (id) => {
    const updatedSongs = songs.map((song) =>
      song.id === id ? { ...song, favourite: !song.favourite } : song
    );
    setSongs(updatedSongs);
  };

  const setMainSong = (songSrc, imgSrc) => {
    setCurrentSong(songSrc);
    setCurrentImage(imgSrc);
    setAutoPlay(true);
  };

  const deleteSong = (id) => {
    axios
      .delete(`http://localhost:3000/songs/${id}`)
      .then(() => {
        console.log("Deleted successfully");
        setSongs((prevSongs) => prevSongs.filter((song) => song.id !== id));
      })
      .catch(() => {
        console.log("Error deleting the song");
      });
  };

  return (
    <div className="AudioList">
      <h2 className="title">
        The list <span>{`${songs.length} songs`}</span>
      </h2>

      {currentSong && (
        <div className="songTracker">
          <img src={currentImage} alt="Current Song" className="trackerImage" />
          <audio controls autoPlay={autoPlay} src={currentSong} className="audioPlayer"></audio>
        </div>
      )}

      <div className="songsContainer">
        {songs.map((song, index) => (
          <div
            className="songCard"
            key={song.id}
            onClick={() => setMainSong(song.song, song.imgSrc)}
          >
            <div className="imgBox">
              <img src={song.imgSrc} alt={song.songName} />
            </div>
            <div className="songDetails">
              <div className="songInfo">
                <p className="songName">{song.songName}</p>
                <p className="artistName">{song.artist}</p>
              </div>
              <div className="songStats">
                <p className="hits">
                  <i>
                    <FaHeadphones />
                  </i>
                  95,490,102
                </p>
                <p className="duration">
                  <i>
                    <FaRegClock />
                  </i>
                  03:04
                </p>
              </div>
              <div className="actions">
                <button
                  className="favouriteButton"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavourite(song.id);
                  }}
                >
                  {song.favourite ? <FaHeart className="favIcon active" /> : <FaRegHeart className="favIcon" />}
                </button>
                <button
                  className="deleteButton"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteSong(song.id);
                  }}
                >
                  <FaTrashAlt />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export { AudioList };
