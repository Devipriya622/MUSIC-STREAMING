import React, { useState, useRef, useEffect } from "react";
import "../styles/MusicPlayer.css";
import {
  FaRegHeart,
  FaHeart,
  FaForward,
  FaStepForward,
  FaStepBackward,
  FaBackward,
  FaPlay,
  FaPause,
  FaShareAlt,
} from "react-icons/fa";
import { BsDownload } from "react-icons/bs";

function MusicPlayer({ song, imgSrc, auto }) {
  const [isLove, setLove] = useState(false);
  const [isPlaying, setPlay] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

  const audioPlayer = useRef(null); // reference to the audio element
  const progressBar = useRef(null); // reference to the progress bar
  const animationRef = useRef(null); // reference to the animation frame

  useEffect(() => {
    const handleMetadataLoad = () => {
      if (audioPlayer.current) {
        const seconds = Math.floor(audioPlayer.current.duration);
        setDuration(seconds);
        progressBar.current.max = seconds;
      }
    };

    if (audioPlayer.current) {
      audioPlayer.current.addEventListener("loadedmetadata", handleMetadataLoad);
    }

    return () => {
      if (audioPlayer.current) {
        audioPlayer.current.removeEventListener("loadedmetadata", handleMetadataLoad);
      }
    };
  }, []);

  useEffect(() => {
    if (auto && audioPlayer.current) {
      audioPlayer.current
        .play()
        .then(() => {
          setPlay(true);
          animationRef.current = requestAnimationFrame(whilePlaying);
        })
        .catch((err) => console.error("Playback issue:", err));
    }
  }, [auto]);

  const whilePlaying = () => {
    if (audioPlayer.current) {
      progressBar.current.value = audioPlayer.current.currentTime;
      updateProgressBarStyle();
      setCurrentTime(audioPlayer.current.currentTime);
      animationRef.current = requestAnimationFrame(whilePlaying);
    }
  };

  const updateProgressBarStyle = () => {
    if (progressBar.current && duration > 0) {
      progressBar.current.style.setProperty(
        "--played-width",
        `${(progressBar.current.value / duration) * 100}%`
      );
    }
  };

  const togglePlayPause = () => {
    if (!isPlaying && audioPlayer.current) {
      audioPlayer.current
        .play()
        .then(() => {
          setPlay(true);
          console.log("heeey")
          animationRef.current = requestAnimationFrame(whilePlaying);
        })
        .catch((err) => console.error("Playback issue:", err));
    } else if (audioPlayer.current) {
      audioPlayer.current.pause();
      cancelAnimationFrame(animationRef.current);
      setPlay(false);
    }
  };

  const calculateTime = (sec) => {
    const minutes = Math.floor(sec / 60);
    const returnMin = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const seconds = Math.floor(sec % 60);
    const returnSec = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${returnMin}:${returnSec}`;
  };

  const handleProgressChange = () => {
    if (audioPlayer.current && progressBar.current) {
      audioPlayer.current.currentTime = progressBar.current.value;
      updateProgressBarStyle();
      setCurrentTime(audioPlayer.current.currentTime);
    }
  };

  const toggleLove = () => {
    setLove((prev) => !prev);
  };

  return (
    <div className="musicPlayer">
      <div className="songImage">
        <img src={imgSrc} alt="Song cover" />
      </div>
      <div className="songAttributes">
        <audio src={song} preload="metadata" ref={audioPlayer} />

        <div className="top">
          <div className="left">
            <div className="loved" onClick={toggleLove}>
              {isLove ? (
                <i>
                  <FaHeart />
                </i>
              ) : (
                <i>
                  <FaRegHeart />
                </i>
              )}
            </div>
            <i className="download">
              <BsDownload />
            </i>
          </div>

          <div className="middle">
            <div className="back">
              <i>
                <FaStepBackward />
              </i>
              <i>
                <FaBackward />
              </i>
            </div>
            <div className="playPause" onClick={togglePlayPause}>
              {isPlaying ? (
                <i>
                  <FaPause />
                </i>
              ) : (
                <i>
                  <FaPlay />
                </i>
              )}
            </div>
            <div className="forward">
              <i>
                <FaForward />
              </i>
              <i>
                <FaStepForward />
              </i>
            </div>
          </div>

          <div className="right">
            <i>
              <FaShareAlt />
            </i>
          </div>
        </div>

        <div className="bottom">
          <div className="currentTime">{calculateTime(currentTime)}</div>
          <input
            type="range"
            className="progressBar"
            ref={progressBar}
            defaultValue="0"
            onChange={handleProgressChange}
          />
          <div className="duration">
            {!isNaN(duration) ? calculateTime(duration) : "00:00"}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MusicPlayer;


