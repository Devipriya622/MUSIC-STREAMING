

import React, { useState } from "react";
import "../styles/LeftMenu.css";
import { FaPlus } from "react-icons/fa";
import { BsMusicNoteList, BsTrash } from "react-icons/bs";
import { PlayList } from "./PlayList";

function MenuPlayList() {
  // State to keep track of the current song index
  const [currentSongIndex, setCurrentSongIndex] = useState(0);

  // Function to handle "Next" button click
  const handleNext = () => {
    setCurrentSongIndex((prevIndex) =>
      prevIndex < PlayList.length - 1 ? prevIndex + 1 : 0 // Loop back to the first song
    );
  };

  // Function to handle "Previous" button click
  const handlePrevious = () => {
    setCurrentSongIndex((prevIndex) =>
      prevIndex > 0 ? prevIndex - 1 : PlayList.length - 1 // Loop to the last song
    );
  };

  return (
    <div className="playListContainer">
      <div className="nameContainer">
        <p>Playlists</p>
        <i>
          <FaPlus />
        </i>
      </div>

      <div className="playListScroll">
        {PlayList &&
          PlayList.map((list, index) => (
            <div
              className={`playLists ${
                index === currentSongIndex ? "active" : ""
              }`}
              key={list.id}
            >
              <i className="list">
                <BsMusicNoteList />
              </i>
              <p>{list.name}</p>
              <i className="trash">
                <BsTrash />
              </i>
            </div>
          ))}
      </div>

      
    </div> 
  );
}

export { MenuPlayList };