const PlayList = [
  {
    id: 1,
    name: "Top Hit 2021-USA",
  },
  {
    id: 2,
    name: "Dance",
  },
  {
    id: 3,
    name: "Relaxing Music",
  },
  {
    id: 4,
    name: "Instrumental",
  },
  {
    id: 5,
    name: "Hip Pop",
  },
  {
    id: 6,
    name: "Workout Musics",
  },
];

export { PlayList };
