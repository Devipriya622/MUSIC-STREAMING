const Songs = [
  {
    id: 1,
    favourite: false,
    songName: "Bella Ciao",
    artist: "El Profesor",
    song: "/songs/song1.mp3",
    imgSrc:
      "/images/image1.jpeg",
  },
  {
    id: 2,
    favourite: false,
    songName: "Hey Rangule",
    artist: "Anurag Kulkarni",
    song: "/songs/song2.mp3",
    imgSrc:
      "/images/image2.jpeg",
  },
  {
    id: 3,
    favourite: false,
    songName: "Pen pove Thenvande",
    artist: "Vishal chandrashekhar,Sharreth,Nithya Mammen",
    song: "/songs/song3.mp3",
    imgSrc:
      "/images/image3.jpeg",
  },
  {
    id: 4,
    favourite: false,
    songName: "Kanunna kalyanam",
    artist: "Vishal chandrashekhar,Anurag Kulkarni,sinduri vishal",
    song: "/songs/song4.mp3",
    imgSrc:
      "/images/image4.jpeg",
  },
  {
    id: 5,
    favourite: false,
    songName: "Ammadi",
    artist: "Shaktisree Gopalan,Kala Bhairava,Hesham Abdul Wahab",
    song: "/songs/song5.mp3",
    imgSrc:
      "/images/image5.jpeg",
  },
  {
    id: 6,
    songName: "Gaaju Bomma",
    artist: "Hesham Abdul Wahab",
    song: "/songs/song6.mp3",
    imgSrc:
      "/images/image6.jpeg",
  },
  {
    id: 7,
    favourite: false,
    songName: "Naalo Nenu",
    artist: "Sameera Bharadwaj",
    song: "/songs/song7.mp3",
    imgSrc:
      "/images/image7.jpeg",
   },
  {
    id: 8,
    favourite: false,
    songName: "Baby",
    artist: "Justin Bieber",
    song: "/songs/song8.mp3",
    imgSrc:
      "/images/image8.jpg",
  },
];

export { Songs };
