// import axios from 'axios';
// import React, { useState } from 'react';

// const AddSong = () => {
//   const [songs, setSongs] = useState([]);
//   const [error, setError] = useState(null); // For error messages

//   const addSong = async (newSong) => {
//     try {
//       await axios.post('http://localhost:3000/songs/', newSong);
//       console.log("Song added successfully");
//       setSongs((prevSongs) => [...prevSongs, newSong]);
//       alert('Song Added')
//     } catch (err) {
//       console.error("Error adding song:", err);
//       setError("Failed to add the song. Please try again.");
//     }
//   };

//   const handleAddSong = (e) => {
//     e.preventDefault();

//     const newSong = {
//       id: Date.now(), // Unique ID based on timestamp
//       songName: e.target.songName.value,
//       artist: e.target.artist.value,
//       imgSrc: e.target.imgSrc.value,
//       song: e.target.songSrc.value,
//       favourite: false,
//     };

//     addSong(newSong);
//     e.target.reset(); // Reset the form after submission
//     setError(null); // Clear any previous errors
//   };

//   return (
//     <div className="add-song-container">
//       <h2 color>Add a New Song</h2>
//       <form onSubmit={handleAddSong} className="addSongForm">
//         <input
//           type="text"
//           name="songName"
//           placeholder="Song Name"
//           required
//         />
//         <input
//           type="text"
//           name="artist"
//           placeholder="Artist"
//           required
//         />
//         <input
//           type="text"
//           name="imgSrc"
//           placeholder="Image URL"
//           required
//         />
//         <input
//           type="text"
//           name="songSrc"
//           placeholder="Song URL"
//           required
//         />
//         <button type="submit">Add Song</button>
//       </form>
//       {error && <p className="error-message">{error}</p>}
//       {/* <div className="song-list">
//         <h3>Current Songs:</h3>
//         <ul>
//           {songs.map((song) => (
//             <li key={song.id}>
//               <strong>{song.songName}</strong> by {song.artist}
//             </li>
//           ))}
//         </ul>
//       </div> */}
//     </div>
//   );
// };

// export default AddSong;
import axios from "axios";
import React, { useState } from "react";

const AddSong = () => {
  const [songs, setSongs] = useState([]);
  const [error, setError] = useState(null);

  const addSong = async (newSong) => {
    try {
      await axios.post("http://localhost:3000/songs/", newSong);
      console.log("Song added successfully");
      setSongs((prevSongs) => [...prevSongs, newSong]);
      alert("Song Added");
    } catch (err) {
      console.error("Error adding song:", err);
      setError("Failed to add the song. Please try again.");
    }
  };

  const handleAddSong = (e) => {
    e.preventDefault();

    const newSong = {
      id: Date.now(),
      songName: e.target.songName.value,
      artist: e.target.artist.value,
      imgSrc: e.target.imgSrc.value,
      song: e.target.songSrc.value,
      favourite: false,
    };

    addSong(newSong);
    e.target.reset();
    setError(null);
  };

  return (
    <div
      style={{
        maxWidth: "500px",
        margin: "50px auto",
        padding: "20px",
        border: "1px solid #ccc",
        borderRadius: "10px",
        backgroundColor: "#f9f9f9",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
      }}
    >
      <h2 style={{ textAlign: "center", color: "#333", marginBottom: "20px" }}>
        Add A New Song
      </h2>
      <form onSubmit={handleAddSong} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
        <input
          type="text"
          name="songName"
          placeholder="Song Name"
          required
          style={{
            padding: "10px",
            fontSize: "16px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        <input
          type="text"
          name="artist"
          placeholder="Artist"
          required
          style={{
            padding: "10px",
            fontSize: "16px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        <input
          type="text"
          name="imgSrc"
          placeholder="Image URL"
          required
          style={{
            padding: "10px",
            fontSize: "16px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        <input
          type="text"
          name="songSrc"
          placeholder="Song URL"
          required
          style={{
            padding: "10px",
            fontSize: "16px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            fontSize: "16px",
            border: "none",
            borderRadius: "5px",
            backgroundColor: "#000",
            color: "#fff",
            cursor: "pointer",
          }}
        >
          Add Song
        </button>
      </form>
      {error && (
        <p
          style={{
            color: "red",
            textAlign: "center",
            marginTop: "15px",
          }}
        >
          {error}
        </p>
      )}
    </div>
  );
};

export default AddSong;
